--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.tb_ruang;
DROP TABLE public.tb_level;
DROP TABLE public.tb_jenis;
DROP TABLE public.petugas;
DROP TABLE public.peminjaman;
DROP TABLE public.inventaris;
DROP TABLE public.detail_pinjam;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjam (
    id_detail_pinjam character varying(12),
    id_inventaris character varying(12),
    jumlah bigint
);


ALTER TABLE detail_pinjam OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris character varying(12),
    nama text,
    kondisi character varying(12),
    keterangan character varying(10),
    jumlah bigint,
    id_jenis character varying(12),
    tanggal_register date,
    id_ruang character varying(12),
    kode_inventaris character varying(12),
    id_petugas character varying(12)
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman character varying(12),
    tanggal_peminjaman date,
    tanggal_kembali date,
    status_peminjaman character varying(10),
    id_pegawai character varying(12)
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying(12),
    username character varying(100),
    password character varying(100),
    nama_petugas text,
    id_level character varying(100)
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: tb_jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_jenis (
    id_jenis character varying(12),
    nama_jenis character varying(100),
    kode_jenis character varying(12),
    keterangan character varying(10)
);


ALTER TABLE tb_jenis OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(12),
    nama_level character varying(100)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_ruang (
    id_ruang character varying(12),
    nama_ruang character varying(100),
    kode_ruang character varying(12),
    keterangan character varying(10)
);


ALTER TABLE tb_ruang OWNER TO postgres;

--
-- Data for Name: detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_peminjaman, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_peminjaman, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2821.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2818.dat';

--
-- Data for Name: tb_jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2815.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: tb_ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2816.dat';

--
-- PostgreSQL database dump complete
--

